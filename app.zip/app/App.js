import React, { useRef, useState } from 'react';
import { SafeAreaView, View, Text, StyleSheet, Image, TouchableOpacity, Switch, TextInput, FlatList, Animated, LayoutAnimation, UIManager, Platform, Alert, ScrollView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator, DrawerContentScrollView, DrawerItemList } from '@react-navigation/drawer';

// Enable LayoutAnimation on Android
if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const Drawer = createDrawerNavigator();

// Sample product data
const PRODUCTS = [
  { id: '1', title: 'Fitness Tracker Watch', image: 'https://istarmax.com/wp-content/uploads/2022/01/s5-black.jpg' },
  { id: '2', title: 'Smart Meal Prep Containers', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShUmQsY0tr7-hGl9Syl8SU2kx9_zqRY_pYmw&s' },
  { id: '3', title: 'Meditation Journal', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjRK661D5Zvw_-wKKzHRDWROxLjTy8i9SBSg&s' },
  { id: '4', title: 'Hydration Reminder Bottle', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnvMluLVxZlJQoGxMsPJLhm-1FjmHc2mZNAA&s' },
  { id: '5', title: 'Healthy Snack Pack', image: 'https://5.imimg.com/data5/SELLER/Default/2024/5/421231938/IW/QR/KM/128728173/healthy-snack-packs-1000x1000.png' },
];

// Custom Drawer Content to show logo and name
function CustomDrawerContent(props) {
  return (
    <DrawerContentScrollView {...props} contentContainerStyle={{ flex: 1 }}>
      <View style={styles.drawerHeader}>
        <Image source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSfvVf_PP8we3GzESnFQeKuKW2uwxDGSDGZQ&s' }} style={styles.drawerLogo} />
        <Text style={styles.drawerTitle}>WellBeing Hub</Text>
      </View>
      <DrawerItemList {...props} />
      <View style={{ flex: 1 }} />
      <View style={styles.drawerFooter}>
        <Text style={{ color: '#fff' }}>© 2025 WellBeing Hub</Text>
      </View>
    </DrawerContentScrollView>
  );
}

function WaterTracker() {
  const [water, setWater] = useState(0);
  const [isEnabled, setIsEnabled] = useState(true);
  const [goal, setGoal] = useState('2000');

  const handleAdd = () => {
    const newWater = water + 250;
    setWater(newWater);
    const goalValue = parseInt(goal) || 2000;

    if (isEnabled) {
      if (newWater >= goalValue) {
        Alert.alert('Goal reached!', `You've reached your goal of ${goalValue} ml!`);
      } else {
        Alert.alert('Water Updated', `You need ${goalValue - newWater} ml more.`);
      }
    }
  };

  const handleCheckGoal = () => {
    const goalValue = parseInt(goal) || 2000;
    const remaining = goalValue - water;

    if (water >= goalValue) {
      Alert.alert('Goal Completed', 'You met your water intake goal!', [
        { text: 'OK' },
        { text: 'Cancel', style: 'cancel' },
      ]);
    } else {
      Alert.alert('Keep Going!', `You still need ${remaining} ml more.`, [
        { text: 'OK' },
        { text: 'Cancel', style: 'cancel' },
      ]);
    }
  };

  return (
    <View style={styles.card}>
      <Text style={styles.sectionTitle}>Water Intake Tracker</Text>

      <View style={styles.rowBetween}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={{ marginRight: 8 }}>Notifications</Text>
          <Switch
            value={isEnabled}
            onValueChange={(value) => {
              setIsEnabled(value);
              Alert.alert('Notifications', value ? 'ON' : 'OFF');
            }}
            trackColor={{ false: '#C8E6C9', true: '#66BB6A' }}
            thumbColor={isEnabled ? '#2E7D32' : '#f4f3f4'}
          />
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <Text style={{ fontWeight: 'bold', color: '#2E7D32' }}>Current: {water} ml</Text>
        </View>
      </View>

      <View style={styles.goalContainerSmall}>
        <Text style={styles.goalLabel}>Daily Goal (ml):</Text>
        <TextInput
          style={styles.goalInputSmall}
          keyboardType="numeric"
          value={goal}
          onChangeText={setGoal}
        />
      </View>

      <View style={styles.progressContainer}>
        <View
          style={[
            styles.progressBar,
            { width: `${Math.min(100, (water / (parseInt(goal) || 2000)) * 100)}%` },
          ]}
        />
      </View>

      <TouchableOpacity style={styles.button} onPress={handleAdd}>
        <Text style={styles.buttonText}>+ Add 250 ml</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.buttonSecondary}
        onPress={() => { setWater(0); Alert.alert('Reset', 'Water reset to 0 ml.'); }}
      >
        <Text style={styles.buttonText}>Reset Intake</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.checkButton} onPress={handleCheckGoal}>
        <Text style={styles.buttonText}>Check Goal</Text>
      </TouchableOpacity>
    </View>
  );
}

function HomeScreen({ navigation }) {
  const [theme, setTheme] = useState('light');
  const [homeTitle, setHomeTitle] = useState('Empower Your Healthy Lifestyle');
  const contactOpacity = useRef(new Animated.Value(1)).current;
  const [productsVisible, setProductsVisible] = useState(true);

  const toggleContactFade = () => {
    Animated.timing(contactOpacity, {
      toValue: contactOpacity._value === 1 ? 0 : 1,
      duration: 400,
      useNativeDriver: true,
    }).start();
  };

  const applyTheme = (mode) => {
    setTheme(mode);
    Alert.alert('Theme', `Applied ${mode} theme`);
  };

  const toggleProductNames = () => {
    // use LayoutAnimation for a simple slide toggle effect of titles
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setProductsVisible((p) => !p);
  };

  return (
    <SafeAreaView style={[styles.container, theme === 'dark' ? styles.darkBackground : styles.lightBackground]}>
      <View style={[styles.header, theme === 'dark' ? styles.darkHeader : null]}>
        <TouchableOpacity onPress={() => navigation.openDrawer()} style={styles.hamburgerButton}>
          <View style={styles.hamburgerLine} />
          <View style={styles.hamburgerLine} />
          <View style={styles.hamburgerLine} />
        </TouchableOpacity>
        <View style={styles.headerContentRow}>
          <Image source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSfvVf_PP8we3GzESnFQeKuKW2uwxDGSDGZQ&s' }} style={styles.logoSmall} />
          <Text style={styles.headerText}>WellBeing Hub</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: 16 }}>

        <View style={styles.sectionHome}>
          <Text style={styles.homeTitle}>{homeTitle}</Text>
          <Text style={styles.homeSubtitle}>Discover tools, guides, and products that make wellness simple and enjoyable.</Text>

          <View style={styles.btnArea}>
            <TouchableOpacity style={styles.smallBtn} onPress={() => { toggleContactFade(); }}>
              <Text style={styles.smallBtnText}>Toggle Connect Section</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.smallBtn} onPress={() => { toggleProductNames(); }}>
              <Text style={styles.smallBtnText}>Toggle Product Names</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.smallBtn} onPress={() => applyTheme('light')}>
              <Text style={styles.smallBtnText}>Apply Light Theme</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.smallBtn} onPress={() => applyTheme('dark')}>
              <Text style={styles.smallBtnText}>Apply Dark Theme</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.smallBtn} onPress={() => setHomeTitle('🌱 Your Path to Wellness Starts Here!')}>
              <Text style={styles.smallBtnText}>Update Home Message</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Plans preview */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionHeading}>Personalized Wellness Plans</Text>
          <Text style={styles.sectionText}>Choose a plan that fits your lifestyle and goals.</Text>
          <Image source={{ uri: 'https://conciergedoctornyc.com/wp-content/uploads/2024/03/NYC-Personalize-Wellness-Plan.png' }} style={styles.plansImage} />
        </View>

        {/* Product Grid Preview - small */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionHeading}>Products</Text>
          <FlatList
            data={PRODUCTS}
            keyExtractor={(item) => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingVertical: 12 }}
            renderItem={({ item }) => (
              <View style={styles.productCardSmall}>
                <Image source={{ uri: item.image }} style={styles.productImageSmall} />
                {productsVisible && <Text style={styles.productTitleSmall}>{item.title}</Text>}
              </View>
            )}
          />
        </View>

        {/* Water tracker included in home */}
        <WaterTracker />

        {/* Contact preview with fade animation */}
        <Animated.View style={[styles.contactCard, { opacity: contactOpacity }]}>
          <Text style={styles.sectionHeading}>Connect</Text>
          <Text>Email: hello@wellbeinghub.com</Text>
          <Text>Phone: +977 9849535168</Text>
          <Text>Address: Baneshwor, Kathmandu</Text>
        </Animated.View>

      </ScrollView>
    </SafeAreaView>
  );
}

function PlansScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={styles.sectionHeading}>Wellness Plans</Text>
        <Text style={styles.sectionText}>Our personalized plans are designed by professionals to match your goals.</Text>

        <View style={styles.planBox}>
          <Text style={{ fontWeight: 'bold' }}>Starter Plan</Text>
          <Text>Weekly check-ins, beginner workout plan, basic nutrition guide.</Text>
        </View>

        <View style={styles.planBox}>
          <Text style={{ fontWeight: 'bold' }}>Balanced Plan</Text>
          <Text>Daily activity tracking, meal plan, guided meditations.</Text>
        </View>

        <View style={styles.planBox}>
          <Text style={{ fontWeight: 'bold' }}>Premium Plan</Text>
          <Text>1:1 coaching, advanced metrics, personalized nutrition.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function ProductsScreen() {
  const [showTitles, setShowTitles] = useState(true);

  const toggleTitles = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setShowTitles((s) => !s);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.headerSimple}>
        <Text style={styles.headerText}>Products</Text>
      </View>

      <View style={{ padding: 12 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 }}>
          <TouchableOpacity style={styles.smallBtn} onPress={toggleTitles}>
            <Text style={styles.smallBtnText}>{showTitles ? 'Hide' : 'Show'} Product Names</Text>
          </TouchableOpacity>
        </View>

        <FlatList
          data={PRODUCTS}
          keyExtractor={(item) => item.id}
          numColumns={2}
          columnWrapperStyle={{ justifyContent: 'space-between' }}
          renderItem={({ item }) => (
            <View style={styles.productBox}>
              <Image source={{ uri: item.image }} style={styles.productImage} />
              {showTitles && <Text style={styles.productTitle}>{item.title}</Text>}
            </View>
          )}
        />
      </View>
    </SafeAreaView>
  );
}

function ContactScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={styles.sectionHeading}>Connect With Us</Text>
        <Text style={{ marginTop: 8 }}>Email: hello@wellbeinghub.com</Text>
        <Text>Phone: +977 9849535168</Text>
        <Text>Address: Baneshwor, Kathmandu</Text>

        <View style={{ marginTop: 20 }}>
          <Text style={{ fontWeight: 'bold' }}>Follow</Text>
          <Text>@wellbeinghub</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator drawerContent={(props) => <CustomDrawerContent {...props} />} screenOptions={{ headerShown: false }}>
        <Drawer.Screen name="Home" component={HomeScreen} />
        <Drawer.Screen name="Plans" component={PlansScreen} />
        <Drawer.Screen name="Products" component={ProductsScreen} />
        <Drawer.Screen name="Contact" component={ContactScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff8e1' },
  lightBackground: { backgroundColor: '#fff8e1' },
  darkBackground: { backgroundColor: '#263238' },
  header: { height: 64, backgroundColor: '#388e3c', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12 },
  darkHeader: { backgroundColor: '#1b5e20' },
  headerContentRow: { flexDirection: 'row', alignItems: 'center', marginLeft: 12 },
  logoSmall: { width: 36, height: 36, borderRadius: 6, marginRight: 8 },
  headerText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  hamburgerButton: { padding: 6 },
  hamburgerLine: { width: 22, height: 2, backgroundColor: '#fff', marginVertical: 2 },

  sectionHome: { marginVertical: 12 },
  homeTitle: { fontSize: 22, fontWeight: 'bold', color: '#1B5E20', marginBottom: 6 },
  homeSubtitle: { color: '#4CAF50', marginBottom: 12 },

  btnArea: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  smallBtn: { backgroundColor: '#388e3c', padding: 10, borderRadius: 10, margin: 6 },
  smallBtnText: { color: '#fff', fontWeight: '600' },

  sectionCard: { backgroundColor: '#E8F5E9', padding: 12, borderRadius: 12, marginBottom: 12 },
  sectionHeading: { fontSize: 18, fontWeight: 'bold', color: '#1B5E20', marginBottom: 6 },
  sectionText: { color: '#333' },
  plansImage: { width: '100%', height: 160, resizeMode: 'cover', borderRadius: 12, marginTop: 10 },

  productCardSmall: { width: 140, marginRight: 12, backgroundColor: '#fff', borderRadius: 10, overflow: 'hidden', elevation: 3 },
  productImageSmall: { width: '100%', height: 100, resizeMode: 'cover' },
  productTitleSmall: { padding: 8, fontWeight: '600' },

  card: { backgroundColor: '#E8F5E9', padding: 12, borderRadius: 12, marginVertical: 12 },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#1B5E20', marginBottom: 8 },

  goalContainerSmall: { flexDirection: 'row', alignItems: 'center', marginTop: 8 },
  goalLabel: { marginRight: 8, color: '#333' },
  goalInputSmall: { borderWidth: 1, borderColor: '#A5D6A7', padding: 6, borderRadius: 8, backgroundColor: '#fff', width: 120 },

  progressContainer: { height: 12, width: '100%', backgroundColor: '#C8E6C9', borderRadius: 10, marginVertical: 12 },
  progressBar: { height: '100%', backgroundColor: '#43A047', borderRadius: 10 },

  button: { backgroundColor: '#388E3C', padding: 10, borderRadius: 10, marginTop: 6 },
  buttonSecondary: { backgroundColor: '#9E9E9E', padding: 10, borderRadius: 10, marginTop: 6 },
  checkButton: { backgroundColor: '#66BB6A', padding: 10, borderRadius: 10, marginTop: 6 },
  buttonText: { color: 'white', textAlign: 'center', fontWeight: 'bold' },

  contactCard: { backgroundColor: '#fff', padding: 12, borderRadius: 12, marginVertical: 12, elevation: 2 },

  // Products screen styles
  headerSimple: { height: 64, backgroundColor: '#388E3C', justifyContent: 'center', paddingLeft: 12 },
  productBox: { width: '48%', backgroundColor: '#fff', borderRadius: 12, marginBottom: 12, overflow: 'hidden', elevation: 3 },
  productImage: { width: '100%', height: 140, resizeMode: 'cover' },
  productTitle: { padding: 10, fontWeight: '600' },

  // Drawer styles
  drawerHeader: { padding: 20, backgroundColor: '#2E7D32', alignItems: 'center' },
  drawerLogo: { width: 70, height: 70, borderRadius: 10, marginBottom: 8 },
  drawerTitle: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  drawerFooter: { padding: 12, alignItems: 'center', backgroundColor: '#388E3C' },

  planBox: { backgroundColor: '#fff', padding: 12, borderRadius: 10, marginTop: 12, elevation: 2 },
});